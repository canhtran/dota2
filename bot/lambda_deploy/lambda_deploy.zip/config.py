PAT = 'EAAKYTN5BHzUBAJSCZAxifrX2jNN3fQ8agaZCq3kup1ZCG1KXBnFux84J46ndvaBgJYZAkZBrI6QkaxRkMfTuaiZCj4u2le8ivvsIWrSRYvwYu41Cyk0o8gJcaok3L4i2VqOLuoqL4ZAfNdFizjV1SoioY2KNENkxqVhqwrZC9GNGTAZDZD'
MESSENGER_TOKEN = 'dota_my_password_verify_me'
FB_ENDPOINT = 'https://graph.facebook.com/v2.6/me/messages'
OPENDOTA_ENDPOINT = 'https://api.opendota.com/api/'
