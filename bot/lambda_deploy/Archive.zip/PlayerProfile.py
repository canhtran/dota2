import common

"""
Generate player profile based on Account ID
"""
def profile_generator(account_id, sender_id):
    common.send_message(sender_id, "Let me see what I have about this player...")
    common.send_indicator(sender_id, "typing_on")
    player = get_player(account_id)
    if player.get("profile"):
        common.send_message(sender_id, "Steam account ID: %s" % account_id)

        name = player.get("profile").get("personaname")

        common.send_message(sender_id, "I know this person, this is %s 👾" % (
            name,
        ))

        common.send_message(sender_id, "Oh, I even have a picture")
        common.send_indicator(sender_id, "typing_on")

        common.send_image(
            sender_id,
            player.get("profile").get("avatarfull"),
        )

        common.send_message(sender_id, "I love it!")

        common.send_message(sender_id, "Let me check about his/her heroes...")
        common.send_indicator(sender_id, "typing_on")

        player_heroes = get_player_heroes(account_id)

        if len(player_heroes) <= 5:
            common.send_message(sender_id, "%s used %d heroes. Let me find some info about them." % (
                name,
                len(player_heroes),
            ))
        else:
            common.send_message(sender_id, "%s used %d heroes, that's impressive. Let me find some of them." % (
                name,
                len(player_heroes),
            ))

        common.send_indicator(sender_id, "typing_on")
        all_heroes = get_heroes_hash()

        for i, hero in enumerate(player_heroes[:5]):
            hero_ = all_heroes[int(hero.get("hero_id"))]
            if i == 0:
                mess = "%s played %d times with %s" % (
                    name,
                    hero.get("games"),
                    hero_.get("localized_name"),
                )
            else:
                mess = "%d times with %s" % (
                    hero.get("games"),
                    hero_.get("localized_name"),
                )
                common.send_indicator(sender_id, "typing_on")
            common.send_message(sender_id, mess)
            common.send_indicator(sender_id, "typing_on")

        moves = recommended_moves(player_heroes[:5])
        if len(moves) > 0:
            common.send_message(sender_id, "Based on these heroes, I would suggest some nice item combinations: 🔪")
            common.send_indicator(sender_id, "typing_on")
            mess = ""
            for move in moves[:3]:
                mess += "%s with %s\n" % (
                humanize(move.get("hero").replace("npc_dota_hero_", "")),
                humanize(move.get("item").replace("item_", "")),
            )
            common.send_message(sender_id, mess)

        common.send_message(sender_id, "I hope that was helpful 🙃")
        common.send_message(sender_id, "I'm happy to help again!")
    else:
        common.send_message(sender_id, "Unfortunately, I cannot find anything. Are you sure this account belongs to a Dota player?")

def player_more_details(account_id, sender_id):
    player_heroes = get_player_heroes(account_id)
    all_heroes = get_heroes_hash()

    for i, hero in enumerate(player_heroes[:5]):
        hero_ = all_heroes[int(hero.get("hero_id"))]
        if i == 0:
            mess = "Player played %d times with %s" % (
                hero.get("games"),
                hero_.get("localized_name"),
            )
        else:
            mess = "%d times with %s" % (
                hero.get("games"),
                hero_.get("localized_name"),
            )

        common.send_message(sender_id, mess)
    common.send_message(sender_id, "I hope that was helpful 🙃")
    common.send_message(sender_id, "I'm happy to help again!")

"""
Get player details from opendota api
"""
def get_player(account_id):
    return common.call_opendata("/players/" + account_id)

"""
Get Win-Lose from opendota api
"""
def get_wl(account_id):
    return common.call_opendata("/players/" + account_id + "/wl")

"""
Get totals statistics and do calculation
"""
def get_player_statistics(account_id):
    totals = common.call_opendata("/players/" + account_id + "/totals")
    statistics = {}
    for item in totals[:8]:
        statistics[item['field']] = round(item['sum'] / item['n'])

    return statistics

def get_player_heroes(account_id):
    return [h for h in common.call_opendata("/players/%s/heroes" % account_id) if h.get("games") > 0]

def get_heroes():
    return common.call_opendata("/heroes")

def get_heroes_hash():
    h = {}
    heroes = get_heroes()
    for hero in heroes:
        h[hero.get("id")] = hero
    return h

def recommended_moves(player_heroes):
    sql = """
    SELECT
        h.name hero,
        i.name item,
        SUM(pm.kills) kills
    FROM
        player_matches pm,
        items i,
        heroes h
    WHERE
        i.id IN (pm.item_0, pm.item_1, pm.item_2, pm.item_3, pm.item_4, pm.item_5)
        AND h.id = pm.hero_id
        AND pm.hero_id IN (%s)
    GROUP BY 1, 2
    ORDER BY 3 DESC
    LIMIT 10
    """
    ids = []
    for h in player_heroes:
        ids.append(h.get("hero_id"))
    return request_opendota("/explorer", {
        'sql': sql % ",".join(ids)
    }).get("rows")
